package Tk::Xrm;
use vars qw($VERSION);
$VERSION = '3.011'; # $Id: //depot/Tk8/Tk/Xrm.pm#11 $
use Tk();
1;
__END__

=cut

