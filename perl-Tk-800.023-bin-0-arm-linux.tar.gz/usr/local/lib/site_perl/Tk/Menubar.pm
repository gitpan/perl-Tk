package Tk::Menubar;
use strict;
use vars qw($VERSION);
$VERSION = '3.015'; # $Id: //depot/Tk8/Tk/Menubar.pm#15 $
use Tk::Frame;
use Tk::Menu;
1;
